package com.example.apnamartassignment;

public class Repo {

    String id, name, avatar_url, url, html_url, full_name, description;

    public String getId() { return id; }

    public String getName() {
        return name;
    }

    public String getAvatar_url() {
        return avatar_url;
    }

    public String getUrl() {
        return url;
    }

    public String getHtml_url() {
        return html_url;
    }

    public String getFull_name() { return full_name; }

    public String getDescription() { return description; }
}
