package com.example.apnamartassignment;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.TextView;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/*
This Main class provides implementation for activity_main.xml, which contains a button that navigates from Main class to the
Repository Display class. The current activity is the launcher activity of the application.
 */
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView loadView;

        loadView = findViewById(R.id.load);

        //OnClickListener implemented to provide functionality for the button "loadView"
        loadView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onhover(loadView);
                Intent load = new Intent(MainActivity.this,RepoDisplayScreen.class);
                startActivity(load);
            }
        });
    }

    //On hover properties provided for the button upon clicking
    public void onhover(TextView v){
        v.setTextColor(Color.WHITE);
        v.setBackgroundColor(Color.BLACK);
    }
}