package com.example.apnamartassignment;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.facebook.shimmer.ShimmerFrameLayout;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

/*
This class is used to provide the list of repositories in a recycler view format.
The ShimmerFrameLayout helps to use the shimmer animation based on the shimmer start and stop methods.
Activity activity_repo_display_screen.xml provides the design layout.
The class calls the Github API using the Retrofit API to get the required repository details, along with the help of JsonPlaceholder class.
JsonPlaceholder class provides the end point url in order to get requests from the respective API.
SwipeRefreshLayout is used to provide pull-to-refresh functionality of the Activity.
Upon error in fetching of repositories, class navigates to a RepoErrorScreen Activity.
 */

public class RepoDisplayScreen extends AppCompatActivity {

    RecyclerView recyclerView;
    ShimmerFrameLayout shimmerFrameLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_repo_display_screen);

        //Supports the Menu bar actions, which here is an activity icon.
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        //Instantiation and calling of start method o Shimmer.
        shimmerFrameLayout = findViewById(R.id.shimmerLayout);
        shimmerFrameLayout.startShimmer();

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        /*
        Instantiating Retrofit with a base_url, provided by the JsonPlaceholder class, and creation of GsonConverterFactory
        to parse through the json and convert the data.
        */
        Retrofit retrofit = new Retrofit.Builder().baseUrl(JsonPlaceholder.base_url).addConverterFactory(GsonConverterFactory.create()).build();

        JsonPlaceholder jsonPlaceholder = retrofit.create(JsonPlaceholder.class);
        //Call to get requests.
        Call<List<Repo>> call = jsonPlaceholder.getRepos();
        call.enqueue(new Callback<List<Repo>>() {
            @Override
            public void onResponse(Call<List<Repo>> call, Response<List<Repo>> response) {
                shimmerFrameLayout.stopShimmer();
                shimmerFrameLayout.setVisibility(View.GONE);
                recyclerView.setVisibility(View.VISIBLE);
                if(response.isSuccessful()){
                   List<Repo> repoList = response.body();
                   RepoAdapter repoAdapter = new RepoAdapter(repoList,RepoDisplayScreen.this);
                   recyclerView.setAdapter(repoAdapter);
                }else{
                    Toast.makeText(RepoDisplayScreen.this,"Data fetching Unsuccessful",Toast.LENGTH_SHORT).show();
                    //Navigating to RepoErrorScreen class upon error incurred.
                    startActivity(new Intent(RepoDisplayScreen.this, RepoErrorScreen.class));
                }
            }

            @Override
            public void onFailure(Call<List<Repo>> call, Throwable t) {
                Toast.makeText(RepoDisplayScreen.this,"Failed to Display the list of Repositories",Toast.LENGTH_SHORT).show();
                //Navigating to RepoErrorScreen class upon error incurred.
                startActivity(new Intent(RepoDisplayScreen.this, RepoErrorScreen.class));
            }
        });

        SwipeRefreshLayout swipeRefreshLayout;
        swipeRefreshLayout = findViewById(R.id.swipeRefresh);

        //Setting onRefreshListener to refresh on swipe, which here, loads the same, or new fresh set of data upon refreshing from API.
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                shimmerFrameLayout = findViewById(R.id.shimmerLayout);
                shimmerFrameLayout.startShimmer();

                recyclerView = findViewById(R.id.recyclerView);
                recyclerView.setHasFixedSize(true);
                recyclerView.setLayoutManager(new LinearLayoutManager(RepoDisplayScreen.this));

                Retrofit retrofit = new Retrofit.Builder().baseUrl(JsonPlaceholder.base_url).addConverterFactory(GsonConverterFactory.create()).build();

                JsonPlaceholder jsonPlaceholder = retrofit.create(JsonPlaceholder.class);
                Call<List<Repo>> call = jsonPlaceholder.getRepos();
                call.enqueue(new Callback<List<Repo>>() {
                    @Override
                    public void onResponse(Call<List<Repo>> call, Response<List<Repo>> response) {
                        shimmerFrameLayout.stopShimmer();
                        shimmerFrameLayout.setVisibility(View.GONE);
                        recyclerView.setVisibility(View.VISIBLE);
                        if(response.isSuccessful()){
                            List<Repo> repoList = response.body();
                            RepoAdapter repoAdapter = new RepoAdapter(repoList,RepoDisplayScreen.this);
                            recyclerView.setAdapter(repoAdapter);
                        }else{
                            Toast.makeText(RepoDisplayScreen.this,"Data fetching Unsuccessful",Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(RepoDisplayScreen.this, RepoErrorScreen.class));
                        }
                    }

                    @Override
                    public void onFailure(Call<List<Repo>> call, Throwable t) {
                        Toast.makeText(RepoDisplayScreen.this,"Failed to Display the list of Repositories",Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(RepoDisplayScreen.this, RepoErrorScreen.class));
                    }
                });
                swipeRefreshLayout.setRefreshing(false);
            }
        });
    }
    //Method to create options in the Menu Bar for the given activity icon.
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add("Exit");
        return super.onCreateOptionsMenu(menu);
    }

    //Method that specifies the action performed on clicking the icon.
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getTitle().equals("Exit")){
            System.exit(1);
        }
        return super.onOptionsItemSelected(item);
    }
}