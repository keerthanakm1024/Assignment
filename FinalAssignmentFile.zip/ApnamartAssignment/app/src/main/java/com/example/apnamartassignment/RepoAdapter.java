package com.example.apnamartassignment;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.List;

import retrofit2.Call;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
/*
This class is the Adapter class for RepoDisplayScreen class, that loads the Viewholder, with list of items for each item in RecyclerView.
It uses the Repo class to plugin the variables for itemView holder.
Methods ItemCount and BindViewHolder help in getting the number of items and binding holder values with get request values respectively.
Implementation os expandable and collapsable view of items is also done here.
 */
public class RepoAdapter extends RecyclerView.Adapter<RepoAdapter.RepoViewHolder> {

    List<Repo> repoList;
    Context context;

    public RepoAdapter(List<Repo> repoList, Context context) {
        this.repoList = repoList;
        this.context = context;
    }

    @NonNull
    @Override
    public RepoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.each_user,parent,false);
        return new RepoViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RepoViewHolder holder, int position) {

        Repo repo = repoList.get(position);
        holder.name.setText("Name : "+repo.getName());
        holder.name1.setText("Name : "+repo.getName());
        holder.repos_url.setText("Repository: "+repo.getUrl());
        holder.url.setText("Link : "+repo.getHtml_url());
        String[] fullname = repo.getFull_name().split("/");
        holder.login.setText("Username : "+fullname[0]);
        holder.login1.setText("Username : "+fullname[0]);
        holder.desc.setText("Description : "+repo.getDescription());
        Glide.with(context).load("https://avatars.githubusercontent.com/u/"+avatarValue(position)+"?v=4").into(holder.avatar_url);
        Glide.with(context).load("https://avatars.githubusercontent.com/u/"+avatarValue(position)+"?v=4").into(holder.avatar1);
    }

    @Override
    public int getItemCount() {
        return repoList.size();
    }

    public class RepoViewHolder extends RecyclerView.ViewHolder{

        TextView login, repos_url, url, name, desc, name1, login1;
        ImageView avatar_url,avatar1;
        LinearLayout ll1;
        CardView card;
        public RepoViewHolder(@NonNull View itemView) {
            super(itemView);

            login = itemView.findViewById(R.id.login);
            repos_url = itemView.findViewById(R.id.repos_url);
            url = itemView.findViewById(R.id.url);
            name = itemView.findViewById(R.id.name);
            desc = itemView.findViewById(R.id.desc);
            avatar_url = itemView.findViewById(R.id.avatar);
            login1 = itemView.findViewById(R.id.login1);
            name1 = itemView.findViewById(R.id.name1);
            avatar1 = itemView.findViewById(R.id.avatar1);
            ll1 = itemView.findViewById(R.id.ll1);
            card = itemView.findViewById(R.id.card);
            ll1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int ll1_value = ll1.getVisibility();
                    if(ll1_value==View.VISIBLE){
                        ll1.setVisibility(View.GONE);
                        card.setVisibility(View.VISIBLE);
                    }
                }
            });
            card.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int card_value = card.getVisibility();
                    if(card_value==View.VISIBLE){
                        card.setVisibility(View.GONE);
                        ll1.setVisibility(View.VISIBLE);
                    }
                }
            });
        }
    }

    public String avatarValue(int position){
        int n;
        Repo r = repoList.get(position);
        String[] name = r.getFull_name().split("/");
        Retrofit retrofit = new Retrofit.Builder().baseUrl(JsonPlaceholder.base_url).addConverterFactory(GsonConverterFactory.create()).build();
        JsonPlaceholder json = retrofit.create(JsonPlaceholder.class);
        Call<String> call = json.getId();
        return r.getId();
    }
}
