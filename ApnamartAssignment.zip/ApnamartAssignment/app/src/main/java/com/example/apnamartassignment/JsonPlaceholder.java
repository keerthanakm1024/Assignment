package com.example.apnamartassignment;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;
//A PlaceHolder class that holds methods which call the API to fetch data, using the @GET annotation, with the help of base url.
public interface JsonPlaceholder {

    String base_url="https://api.github.com/";

    @GET("repositories")
    Call<List<Repo>> getRepos();

    @GET("users")
    Call<String> getId();
}
