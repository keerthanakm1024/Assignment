package com.example.apnamartassignment;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
/*
This class is called when there is an error in fetching the repositories from API.
It loads the Repository Display page upon clicking the button retry.
 */

public class RepoErrorScreen extends AppCompatActivity {

    Button retry;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_refresh_error_screen);

        //Supports the Menu bar actions, which here is an activity icon.
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        retry = findViewById(R.id.retry);

        retry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(RepoErrorScreen.this,RepoDisplayScreen.class));
            }
        });
    }
    //Method to create options in the Menu Bar for the given activity icon.
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add("Exit");
        return super.onCreateOptionsMenu(menu);
    }

    //Method that specifies the action performed on clicking the icon.
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getTitle().equals("Exit")){
            System.exit(1);
        }
        return super.onOptionsItemSelected(item);
    }
}